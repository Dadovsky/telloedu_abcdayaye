#!/bin/bash

python3 setup.py install
